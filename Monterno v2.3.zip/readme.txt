Hey thank you for buying Montérno!

This theme overwrites a lot of files in Pterodactyl. So please install your addons after installing this themes, to save your time.

1. Make sure you have the dependencies for building the Panel assets:
https://pterodactyl.io/community/customization/panel.html

2. Once you have done this, replace the files with those provided in this .ZIP
!! Please note that these are only the files that have been modified in the theme. You must therefore ensure that you only replace these files. Do NOT delete any files!

3. When the files have been successfully installed, run the following commands:
| cd /var/www/pterodactyl
| yarn build:production
| php artisan view:clear

4. The theme should be installed after the last command. You can now change the theme colors in:
/resources/scripts/CustomColors.tsx

If you have any problems you can contact us in the following discord server: https://discord.gg/geCjrRbAwC

This theme is made by Techno1Monkey#1424.