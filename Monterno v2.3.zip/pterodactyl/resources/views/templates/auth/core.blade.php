@extends('templates/wrapper', [
    'css' => ['body' => 'bg-neutral-900']
])

@section('container')
    <div id="app"></div>

    <script>
        localStorage.setItem("username", "PepijnWeijers");
        localStorage.setItem("BuyerID", "1096");
        localStorage.setItem("TransactionID", "SELLER_DOWNLOADED");
    </script>
@endsection
